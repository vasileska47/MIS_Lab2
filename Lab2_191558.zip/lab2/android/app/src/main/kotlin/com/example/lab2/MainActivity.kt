package com.example.lab2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
