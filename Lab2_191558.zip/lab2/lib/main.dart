import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sara Vasileska 191558',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.lightBlue),
        useMaterial3: true,
      ),
      home: const ClothesShop(title: 'Sara Vasileska 191558'),
    );
  }
}

class ClothesShop extends StatefulWidget {
  const ClothesShop({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<ClothesShop> createState() => _ClothesShopState();
}

class _ClothesShopState extends State<ClothesShop> {
  List<String> _clothes = [
    "T-shirt",
    "Blouse",
    "Jeans",
    "Trousers",
    "Shoes",
    "Dress"
  ];

  int? _selectedIndex;

  void _selectItem(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void addClothes() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String newClothes = "";
        return AlertDialog(
          title: const Text("Add new piece of clothing"),
          content: TextField(
            onChanged: (value) {
              newClothes = value;
            },
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                setState(() {
                  if (newClothes.isNotEmpty) {
                    _clothes.add(newClothes);
                  }
                  Navigator.pop(context);
                });
              },
              child: const Text("Add Clothes"),
            ),
          ],
        );
      },
    );
  }

  void deleteClothes() {
    setState(() {
      if (_selectedIndex != null) {
        _clothes.removeAt(_selectedIndex!);
        _selectedIndex = null;
      }
    });
  }

  void editClothes() {
    if (_selectedIndex != null) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          String editedClothes = _clothes[_selectedIndex!];
          return AlertDialog(
            title: const Text("Edit piece of clothing"),
            content: TextField(
              onChanged: (value) {
                editedClothes = value;
              },
              controller: TextEditingController(text: _clothes[_selectedIndex!]),
            ),
            actions: [
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    if (editedClothes.isNotEmpty) {
                      _clothes[_selectedIndex!] = editedClothes;
                      _selectedIndex = null;
                    }
                    Navigator.pop(context);
                  });
                },
                child: const Text("Save"),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Clothes List - 191558"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: ListView.builder(
        itemCount: _clothes.length,
        itemBuilder: (context, index) {
          return Card(
            key: Key(_clothes[index]),
            child: ListTile(
              title: Text(
                _clothes[index],
                style: const TextStyle(fontSize: 18),
              ),
              onTap: () {
                _selectItem(index);
              },
              selected: _selectedIndex == index,
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: addClothes,
        backgroundColor: Colors.green,
        child: const Icon(Icons.add_box_outlined),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            TextButton(
              onPressed: deleteClothes,
              child: Text('Delete'),
              style: TextButton.styleFrom(
                primary: _selectedIndex != null ? Colors.red : Colors.grey,
              ),
            ),
            TextButton(
              onPressed: editClothes,
              child: Text('Edit'),
              style: TextButton.styleFrom(
                primary: _selectedIndex != null ? Colors.red : Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }
}