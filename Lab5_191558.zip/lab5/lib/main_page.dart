import 'package:flutter/material.dart';


class MyHomePage extends StatelessWidget {
  final String title;
  final List<String> elements;
  const MyHomePage({required this.title, required this.elements});

  get index => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          IconButton(
            icon: Icon(Icons.calendar_today_sharp),
            onPressed: () => print("calendar"),
          ),
          IconButton(
            icon: Icon(Icons.location_on_rounded),
            onPressed: () => print("maps"),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () => print("Tapped"),
      ),
      body: ListView.builder(
        itemCount: elements.length,
        itemBuilder: (context, index) {
          return buildCard(context, elements[index]);
        },
      ),
    );
  }

  Widget buildCard(BuildContext context, String element) {
    return Card(
      elevation: 2,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(10),
            margin: EdgeInsets.all(10),
            child: Text("Exam"),
          ),
          Container(
            margin: EdgeInsets.all(10),
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              border: Border.all(
                color: Theme.of(context).primaryColorDark,
                width: 3,
              ),
            ),
            child: Text(
              element,
              style: TextStyle(
                fontSize: 20,
                color: Theme.of(context).primaryColorLight,
              ),
            ),
          ),
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              print("$index");
            },
          ),
        ],
      ),
    );
  }
}