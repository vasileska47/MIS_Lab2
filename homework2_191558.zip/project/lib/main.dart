import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:project/login.dart';

void main() {
  runApp(MyLibraryApp());
}

class MyLibraryApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => MyLibraryState(),
      child: MaterialApp(
        title: 'My Library - 191558',
        initialRoute: 'login',
        routes: {
          'login': (context) => MyLogin(),
          'page': (context) => MyLibraryHomePage()
        },
        theme: ThemeData(
          primaryColor: Colors.lightGreen[700], // Header color
          hintColor: Colors.lightGreen[300], // Accent color
          scaffoldBackgroundColor: Colors.lightGreen[50], // Scaffold background color
          textTheme: TextTheme(
            bodyText1: TextStyle(color: Colors.black87), // Text color
          ),
        ),
        home: MyLibraryHomePage(),
      ),
    );
  }
}

class MyLibraryHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final myLibrarystate = Provider.of<MyLibraryState>(context, listen: false);
    return Scaffold(
      appBar: AppBar(
        title: Text('My Library - 191558'),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text(
              'Welcome to My Library',
              style: TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 15.0),
            Expanded(
              child: FutureBuilder(
                future: myLibrarystate.fetchBooks(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  } else {
                    return GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 4.0,
                        mainAxisSpacing: 4.0,
                      ),
                      itemCount: myLibrarystate.books.length,
                      itemBuilder: (context, index) {
                        return Books(book: myLibrarystate.books[index]);
                      },
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class Books extends StatefulWidget {
  final Book book;

  Books({required this.book});

  @override
  _BooksState createState() => _BooksState();
}

class _BooksState extends State<Books> {
  bool isFavorite = false;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BookDetailsPage(book: widget.book),
          ),
        );
      },
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
        color: Colors.lightGreen[100], // Book color
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              widget.book.title,
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 4.0),
            Text(
              'by ${widget.book.author}',
              style: TextStyle(
                fontSize: 14.0,
              ),
            ),
            SizedBox(height: 8.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  icon: Icon(
                    isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: isFavorite ? Colors.red : null,
                  ),
                  onPressed: () {
                    setState(() {
                      isFavorite = !isFavorite;
                    });
                  },
                ),
                IconButton(
                  icon: Icon(Icons.share),
                  onPressed: () {
                    // Implement your share action here
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


class BookDetailsPage extends StatelessWidget {
  final Book book;

  BookDetailsPage({required this.book});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Book Details'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Title: ${book.title}',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Text(
              'Author: ${book.author}',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReadPage(book: book),
                  ),
                );
              },
              child: Text('Read'),
            ),
          ],
        ),
      ),
    );
  }
}

class ReadPage extends StatelessWidget {
  final Book book;

  ReadPage({required this.book});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Read ${book.title}'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Title: ${book.title}',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Text(
              'Author: ${book.author}',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            // Here you can add more UI elements for reading the book
            ElevatedButton(
              onPressed: () {
                // Add functionality for reading the book
                // For example, you can open a PDF viewer or load content from a URL
              },
              child: Text('Read Now'),
            ),
          ],
        ),
      ),
    );
  }
}

class Book {
  final String title;
  final String author;

  Book({required this.title, required this.author});
}

class MyLibraryState extends ChangeNotifier {
  List<Book> books = [];

  Future<void> fetchBooks() async {
    // Simulate delay
    await Future.delayed(Duration(seconds: 2));
    books = [
      Book(title: 'The Patient', author: 'Sebastian Fitzek'),
      Book(title: 'Find You First', author: 'Linwood Barclay'),
      Book(title: 'Catch Me', author: 'Lisa Gardner'),
      Book(title: 'The Last Flight', author: 'Julie Clark'),
      Book(title: 'The Housemaid', author: 'Frieda McFadden'),
      Book(title: 'Gone Girl', author: 'Gillian Flynn'),
      Book(title: 'The Girl on the Train', author: 'Paula Hawkins'),
      Book(title: 'The Silent Patient', author: 'Alex Michaelides'),
      Book(title: 'The Guest List', author: 'Lucy Foley'),
      Book(title: 'Lock Every Door', author: 'Riley Sager'),
    ];
    notifyListeners();
  }
}