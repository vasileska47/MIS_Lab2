import 'package:flutter/material.dart';
import './main_page.dart';
import './login.dart';

void main() {
  runApp(MaterialApp(
    // Application name
    title: 'Exam Scheduler - 191558',
    debugShowCheckedModeBanner: false,
    initialRoute: 'login',
    routes: {
      'login': (context) => MyLogin(),
      'main_page': (context) => MyHomePage(
        title: 'Exam Scheduler',
        elements: [
          "Monday 19th 17:00h",
          "Monday 19th 12:30h",
          "Tuesday 20th 8:00h",
          "Wednesday 21st 16:30h",
          "Wednesday 21tst 17:00h",
          "Friday 23rd 13:00h",
          "Monday 26th 12:30h",
        ],
      ),
    },

    theme: ThemeData(
      primarySwatch: Colors.pink,
    ),
  ));
}
