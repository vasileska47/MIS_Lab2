import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sara Vasileska 191558',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ColloquiumsAndExams(),
    );
  }
}

class ColloquiumsAndExams extends StatefulWidget {
  @override
  _ColloquiumsAndExamsState createState() => _ColloquiumsAndExamsState();
}

class _ColloquiumsAndExamsState extends State<ColloquiumsAndExams> {
  List<Map<String, dynamic>> appointments = [];

  @override
  void initState() {
    super.initState();
    // Initialize colloquiums with random dates
    _initializeColloquiums();
  }

  void _initializeColloquiums() {
    final List<String> colloquiumNames =
    [ 'Databases',
      'Introduction to Data Science',
      'Web Programming',
      'Mobile Information Systems',
      'Video Game Programming',
      'Team Project'];
    final Random random = Random();

    for (String colloquiumName in colloquiumNames) {
      final int daysToAdd = random.nextInt(30); // Random number of days between 0 and 30
      final DateTime date = DateTime.now().add(Duration(days: daysToAdd));

      appointments.add({
        'Subject': colloquiumName,
        'Date': '${date.year}-${date.month}-${date.day}',
        'Time': '${date.hour}:${date.minute}',
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Colloquiums and Exams - 191558'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              _addAppointment(context);
            },
          ),
        ],
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 4.0,
          mainAxisSpacing: 4.0,
        ),
        itemCount: appointments.length,
        itemBuilder: (context, index) {
          return AppointmentCard(
            Subject: appointments[index]['Subject'],
            Date: appointments[index]['Date'],
            Time: appointments[index]['Time'],
          );
        },
      ),
    );
  }

  void _addAppointment(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String Subject = '';
        String Date = '';
        String Time = '';
        return AlertDialog(
          title: Text("Add new appointment"),
          content: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                TextField(
                  onChanged: (value) {
                    Subject = value;
                  },
                  decoration: InputDecoration(labelText: 'Subject'),
                ),
                TextField(
                  onChanged: (value) {
                    Date = value;
                  },
                  decoration: InputDecoration(labelText: 'Date'),
                ),
                TextField(
                  onChanged: (value) {
                    Time = value;
                  },
                  decoration: InputDecoration(labelText: 'Time'),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            ElevatedButton(
              onPressed: () {
                if (Subject.isNotEmpty && Date.isNotEmpty && Time.isNotEmpty) {
                  setState(() {
                    appointments.add({
                      'Subject': Subject,
                      'Date': Date,
                      'Time': Time,
                    });
                  });
                  Navigator.of(context).pop();
                }
              },
              child: Text('Add'),
            ),
          ],
        );
      },
    );
  }
}

class AppointmentCard extends StatelessWidget {
  final String Subject;
  final String Date;
  final String Time;

  AppointmentCard({
    required this.Subject,
    required this.Date,
    required this.Time,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            Subject,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8.0),
          Text(
            '$Date - $Time',
            style: TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }
}