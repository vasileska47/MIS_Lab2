package com.example.lab3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
